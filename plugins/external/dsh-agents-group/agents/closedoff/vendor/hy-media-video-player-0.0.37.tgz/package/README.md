## @hy-media/video-player

## 初始化

> 标准项目默认已注册，不需初始化

> 注意：
- node_modules\@hy-media\video-player\lib\plugin\jessibuca 下的文件夹复制到/public/plugin/jessibuca 中, 否则指定resUrl为plugin/jessibuca
- index.html 中引入 /public/plugin/jessibuca

<details>
<summary>展开</summary>

此包强依赖[JessibucaPro](http://10.2.163.218:3001/api.html), 点击此处查询API

```js
import hyVideoPlayer from '@hy-media/video-player';
import '@hy-media/video-player/lib/style.css'

/** 视频播放 -- 公司内部业务的直播和视频回放插件   */
/** 基于backend_system_template的项目默认已注册  */
createApp(App).use(
  hyVideoPlayer,
  {                               /** 全局默认配置，可选 */
  // isDev: true,                 // 是否开发模式
  // resUrl: 'plugin/jessibuca',  // jessibuca插件位置
  // isAi: false                  // 默认是否开启ai识别框
  }
) 
```
</details>

## 独立使用
```html
// 简单使用
<hy-video-player url="wss://msgxsp.scshyzh.cn:11180/ai_live/5503.live.flv" />

<hy-video-player url="http://10.2.163.234:16080/LD202507140002/20250716144547.mp4" />

<hy-video-player url="https://msgxvod.scshyzh.cn:8848/hls/02da5028-4b1f-11f0-98df-0242ac160002/master.m3u8" />
```

## 支持的全部配置项 

> 以下为默认值 (只需配置改变项即可)

<details>
<summary>展开</summary>

```html
<hy-video-player
  :url="'https://msgxvod.scshyzh.cn:8848/hls/02da5028-4b1f-11f0-98df-0242ac160002/master.m3u8'" 
  :controlAutoHide="true" // 底部控制栏是否自动隐藏
  :isAi="false" // ai视频
  :autoPlay="true"
  :timeoutNum="20" //超时次数

  :config="{
    controlHtml:'<div>自定义底部控制栏</div>',
    hiddenControl: true,    // 隐藏底部控制栏
    isResize: false         // 保证原始宽高比
    /* ... 原生的顶级配置, 见顶部入口 */ 
  }"

  :configOperates="{      // 操作按钮(原生)
    showBandwidth: true,  // 显示网速
    fullscreen: true,     // 可全屏
    screenshot: true,     // 截图
    record: true,         // 录制视频
    zoom: true,           // 放大
    ai: true,             // ai视频切换

    ptz: false,   // PTZ轮盘按钮
    close: false, //关闭按钮(会销毁播放器)
    scale: false, //scale(拉伸、缩放)按钮
    /** ... 原生的操作按钮 等价原生的operateBtns， 见顶部入口  */
  }"
 
  :configOperatesExtend="[  // 操作按钮扩展（自定义），operate事件回调
     {
        name: 'testBtn2',
        index: 0, // 顺序
        icon: 'data:image/png;base64,iVBORw0K...',      // 图标 base64图片
        iconHover: 'data:image/png;base64,iVBORw0K...', // 图标 活动状态 base64图片
        iconTitle: '测试hover2',
      }
      /** ... 自己扩展操作按钮 等价原生的operatesExtend， 见顶部入口 */
  ]"
  @operate="(obj)=>{}" // 操作按钮 回调事件
  @statusChange="({type, data})=>{}" // 播放状态发生改变，通过type区分： playFailedAndPaused|放失败后，没有触发任何的重播机制，error|播放错误
  @currentPts="pts=>{}" // 当前展示幁时间, 方便contentList展示自定义数据
  resUrl='plugin/jessibuca' // 依赖插件jessibuca的位置
  style="width: 600px; height: 330px; border: 10px solid tomato" /** 一定要给宽高 */
  @getVideoInfo="obj=>{}" // 获取视频的基本信息，如宽高
/>
```
</details>


## contentList 使用格式说明

<details>
<summary>展开</summary>

```js
let fill = 'green'
const contentList =[
  // 文字
  {
      type: 'text',
      text: 'hello world 你好',
      x: 100, 
      y: 100,
      color: 'red',
      fontSize: 20
  },

  // 矩形
  { type: 'rect',
    x: 800,
    y: 600,
    width: 100,
    height: 100,
    color: '#FF0000',
    fill: fill ? fill : '',
    fillOpacity: fill ? 0.1 : '',
  },

  // 文字加矩形
  {   type: 'rect',
      x: 20,
      y: 30,
      width: 100,
      height: 100,
      color: '#0000FF',
      fill: fill ? fill : '',
      fillOpacity: fill ? 0.3 : '',
  },
  {   type: 'text',
      text: 'hello world 你好',
      x: 20,
      y: 30 - 25,
      width: 100,
      height: 100,
      color: '#0000FF',
  }，

  // 多边形
  {   type: 'polygon',
      color: 'red',
      lineWidth: 2,
      list: [{x: 100, y: 50},{x:300, y:60},{x:900, y:160}],
      fill: fill ? fill : '', // 填充色 可选
      fillOpacity: fill ? 0.3 : '', // 填充色透明度
  },

  // 线条
  { type: 'line',
    color: 'red',
    lineWidth: 2,
    x1: 5,
    y1: 5,
    x2: 80,
    y2: 80
  }
]
```
</details>


## 迭代日志
> v0.0.37
- fix QQ浏览器异常错误

> v0.0.36
- jessibuca 插件内部维护方式优化，见顶部【注意】

> v0.0.30
- fix: 修复url切换 回放和直播

> v0.0.29
- 新增方法getVideoInfo， 获取视频基本信息（宽/高=分辨率）

> v0.0.28
- contentList自定义信息和ai视频 同时支持

> v0.0.27
- contentList支持了归一化数据
<details>
<summary>展开</summary>

```js
 {
    type: 'rect',
    x: 0.3,   // 大于1为像素位置
    y: 0.4,   // 大于1为像素位置 
    width: 0.94, // 大于1为像素长度
    height: 0.94, // 大于1为像素高度
    color: '#0000FF',
    fill: 'yellow',
    fillOpacity: 0.3
  }
```
</details>

> v0.0.26
- 获取当前展示幁时间的方法 currentPts

> v0.0.25 ptz完善了ptz轮盘的相关功能
<details>
<summary>展开</summary>

```js
:config = {
 ptzZoomShow:true,
 ptzMoreArrowShow:true,
 ptzApertureShow:true,
 ptzCruiseShow:true,
 ptzFogShow: true,
 ptzWiperShow: true,
 ptzPositionConfig: {
   left: 10,
   right:10,
   top:10,
   bottom:10
 }
}
:configOperates={
  ptz: true // 轮盘操作入口
}
@operate="(obj)=>{}" //type=='ptz' 事件回调
```
</details>

> v0.0.24 添加contentList配置项，
- 视频上绘制自定义消息(暂时不考虑ai视频)

> v0.0.23
- 关键帧跳转(视频跳转)问题修复

> v0.0.22
- add: 播放状态发生改变方法statusChange，通过type区分： playFailedAndPaused|放失败后，没有触发任何的重播机制，error|播放错误

> v0.0.21
- test: 完善文档说明

> v0.0.20
- fix: mp4格式回放地址支持

> v0.0.19
- fix: 视频点播bug修复

> v0.0.18
- 使用文档更新，无功能更新

> v0.0.17, v0.0.16, v0.0.15， v0.0.14
- 默认ai展示修复

> v0.0.13
- ai切换方式修复和优化

> v0.0.12
- 断线重连3次
- 超时尝试5次
- 超时20s

> v0.0.11
- url更新时的注销 和 ai切换优化

> v0.0.10
- 默认超时时间 20s

> v0.0.9
- 超时报错修复

> v0.0.8
- 布局样式修复